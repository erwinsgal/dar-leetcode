public class Iterations {
    public static void main(String[] args) {
        System.out.println(numberOfSteps(123));
    }
    public static int numberOfSteps(int num) {
        int n=num;
        int count=0;
        while(n>0) {
            if(n%2==0) {
                n=n/2;
                count++;
            }
            if(n%2!=0)
            {
                n=n-1;
                count++;
            }
        }
        return count;
    }
}
