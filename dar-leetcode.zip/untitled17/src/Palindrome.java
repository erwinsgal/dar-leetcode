public class Palindrome {
    public static void main(String[] args) {

        System.out.println(isPalindrome(12));

    }
    public static boolean isPalindrome(int x) {

        String input = String.valueOf(x);
        String palindrome = new StringBuilder(input).reverse().toString();
        return input.equals(palindrome);
    }
}
