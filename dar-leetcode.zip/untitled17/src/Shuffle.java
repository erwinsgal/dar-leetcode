public class Shuffle {
    public static void main(String[] args) {
        System.out.println(restoreString("abc", new int[]{0, 1, 2}));
    }
    public static String restoreString(String s, int[] indices) {

                int strLength = s.length();
                StringBuilder stringBuilder = new StringBuilder(s);

                for (int i = 0; i < strLength; i++) {
                    stringBuilder.setCharAt(indices[i], s.charAt(i));
                }
            return stringBuilder.toString();

    }
}

