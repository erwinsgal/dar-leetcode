import java.util.Arrays;

public class Unique {
    public static void main(String[] args) {
        System.out.println(sumZero(5));
    }
    public static String sumZero(int n) {
        int[] arr = new int[n];
        int numToAdd=1;
        int currPosition = 0;
        if ( n % 2 == 1) {
            arr[currPosition++] = 0;
        }

        while (currPosition<arr.length) {
            arr[currPosition++] = numToAdd;
            arr[currPosition++] = -numToAdd;
            numToAdd++;
        }
        return Arrays.toString(arr);
    }
}
